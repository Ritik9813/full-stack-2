function Footer() {
  return (
    <footer className="footer">
      <p>© 2026 Blogify. All Rights Reserved.</p>
    </footer>
  );
}

export default Footer;
