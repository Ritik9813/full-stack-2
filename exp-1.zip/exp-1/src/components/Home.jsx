function Home() {
  return (
    <div>
      <h2>Home Page</h2>
      <p>Welcome on my website.</p>
    </div>
  );
}

export default Home;
