function Contact() {
  return (
    <div>
      <h2>Contact Page</h2>
      <p>Email: Ritik@gmail.com.com</p>
    </div>
  );
}

export default Contact;
