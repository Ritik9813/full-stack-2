function About() {
  return (
    <div>
      <h2>About Me</h2>
      <p>My name is Ritik kumar singh</p>
      <p>my uid is 23BIA50035</p>
    </div>
  );
}

export default About;
