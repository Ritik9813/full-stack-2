import Home from './Pages/home';

function App() {
  return <Home />;
}

export default App;
